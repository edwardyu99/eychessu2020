#ifndef bookmain_H
#define bookmain_H

#include <string>
//#include <jni.h>
//JNIEnv* create_vm();

//int srchbook(JNIEnv*, int eboard[], int side);
//20190912 int bookmain(std::string argstr);
int bookmain(char argstr[]);	
#endif
