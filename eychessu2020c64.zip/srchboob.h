#ifndef srchboob_H
#define srchboob_H

//#include <jni.h>
//JNIEnv* create_vm();

//int srchbook(JNIEnv*, int eboard[], int side);
//20190912 int srchboob(int eboard[], int side);
int srchboob(unsigned char eboard[], int side);

#endif
